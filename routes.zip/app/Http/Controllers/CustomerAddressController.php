<?php

namespace App\Http\Controllers;

use App\CustomerAddress;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class CustomerAddressController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param CustomerAddress $customerAddress
     * @return Response
     */
    public function show(CustomerAddress $customerAddress)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param CustomerAddress $customerAddress
     * @return Response
     */
    public function edit(CustomerAddress $customerAddress)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param CustomerAddress $customerAddress
     * @return Response
     */
    public function update(Request $request, CustomerAddress $customerAddress)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param CustomerAddress $customerAddress
     * @return Response
     */
    public function destroy(CustomerAddress $customerAddress)
    {
        //
    }
}
