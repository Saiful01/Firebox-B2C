<?php

namespace App\Http\Controllers;

use App\WholeSaleProductImage;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class WholeSaleProductImageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param WholeSaleProductImage $wholeSaleProductImage
     * @return Response
     */
    public function show(WholeSaleProductImage $wholeSaleProductImage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param WholeSaleProductImage $wholeSaleProductImage
     * @return Response
     */
    public function edit(WholeSaleProductImage $wholeSaleProductImage)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param WholeSaleProductImage $wholeSaleProductImage
     * @return Response
     */
    public function update(Request $request, WholeSaleProductImage $wholeSaleProductImage)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param WholeSaleProductImage $wholeSaleProductImage
     * @return Response
     */
    public function destroy(WholeSaleProductImage $wholeSaleProductImage)
    {
        //
    }
}
