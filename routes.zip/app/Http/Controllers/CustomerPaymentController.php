<?php

namespace App\Http\Controllers;

use App\CustomerPayment;
use Illuminate\Http\Request;

class CustomerPaymentController extends Controller
{

}
