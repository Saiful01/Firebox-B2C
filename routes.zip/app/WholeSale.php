<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WholeSale extends Model
{
    //
    public $timestamps=true;
    protected $guarded=[];
}
