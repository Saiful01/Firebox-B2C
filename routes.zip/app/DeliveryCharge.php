<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DeliveryCharge extends Model
{
    public $timestamps=true;
    protected $guarded=[];
}
