
<script type="text/javascript">
    var et_animation_data = [{
        "class": "et_pb_image_0",
        "style": "zoomBottom",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "0ms",
        "intensity": "9%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_text_1",
        "style": "fade",
        "repeat": "once",
        "duration": "550ms",
        "delay": "0ms",
        "intensity": "50%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_blurb_0",
        "style": "zoomBottom",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "0ms",
        "intensity": "10%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_blurb_1",
        "style": "zoomBottom",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "0ms",
        "intensity": "10%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_blurb_2",
        "style": "zoomBottom",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "0ms",
        "intensity": "10%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_blurb_3",
        "style": "zoomBottom",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "0ms",
        "intensity": "10%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_text_2",
        "style": "fade",
        "repeat": "once",
        "duration": "550ms",
        "delay": "0ms",
        "intensity": "50%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_text_3",
        "style": "fade",
        "repeat": "once",
        "duration": "550ms",
        "delay": "0ms",
        "intensity": "50%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_text_4",
        "style": "fade",
        "repeat": "once",
        "duration": "550ms",
        "delay": "0ms",
        "intensity": "50%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_text_6",
        "style": "fade",
        "repeat": "once",
        "duration": "550ms",
        "delay": "0ms",
        "intensity": "50%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_text_8",
        "style": "fade",
        "repeat": "once",
        "duration": "550ms",
        "delay": "0ms",
        "intensity": "50%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }];
</script>
<script type='text/javascript'>
    /* <![CDATA[ */
    var DIVI = {"item_count": "%d Item", "items_count": "%d Items"};
    var et_shortcodes_strings = {"previous": "Previous", "next": "Next"};
    var et_pb_custom = {
        "ajaxurl": "https:\/\/joldi.com.bd\/wp-admin\/admin-ajax.php",
        "images_uri": "https:\/\/joldi.com.bd\/wp-content\/themes\/Divi\/images",
        "builder_images_uri": "https:\/\/joldi.com.bd\/wp-content\/themes\/Divi\/includes\/builder\/images",
        "et_frontend_nonce": "a01886b1a0",
        "subscription_failed": "Please, check the fields below to make sure you entered the correct information.",
        "et_ab_log_nonce": "ea58a9307d",
        "fill_message": "Please, fill in the following fields:",
        "contact_error_message": "Please, fix the following errors:",
        "invalid": "Invalid email",
        "captcha": "Captcha",
        "prev": "Prev",
        "previous": "Previous",
        "next": "Next",
        "wrong_captcha": "You entered the wrong number in captcha.",
        "is_builder_plugin_used": "",
        "ignore_waypoints": "no",
        "is_divi_theme_used": "1",
        "widget_search_selector": ".widget_search",
        "is_ab_testing_active": "",
        "page_id": "440",
        "unique_test_id": "",
        "ab_bounce_rate": "5",
        "is_cache_plugin_active": "no",
        "is_shortcode_tracking": ""
    };
    var et_pb_box_shadow_elements = [];
    /* ]]> */
</script>
<script type='text/javascript' src='https://joldi.com.bd/wp-content/themes/Divi/js/custom.min.js?ver=3.9'></script>
<script type='text/javascript'
        src='https://joldi.com.bd/wp-content/themes/Divi/core/admin/js/common.js?ver=3.9'></script>
<script type='text/javascript' src='https://joldi.com.bd/wp-includes/js/wp-embed.min.js?ver=5.3.2'></script>
<!-- JAVASCRIPT -->
<script src="{{asset('/assets/libs/jquery/jquery.min.js')}}"></script>
<script src="{{asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('assets/libs/metismenu/metisMenu.min.js')}}"></script>
<script src="{{asset('assets/libs/simplebar/simplebar.min.js')}}"></script>
<script src="{{asset('assets/libs/node-waves/waves.min.js')}}"></script>

<!-- Peity chart-->
<script src="{{asset('assets/libs/peity/jquery.peity.min.js')}}"></script>

<!-- Plugin Js-->
<script src="{{asset('assets/libs/chartist/chartist.min.js')}}"></script>
<script src="{{asset('assets/libs/chartist-plugin-tooltips/chartist-plugin-tooltip.min.js')}}"></script>

<script src="{{asset('assets/js/pages/dashboard.init.js')}}"></script>


<!--Form start-->
<script src="/assets/libs/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script src="/assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>

<script src="/assets/js/pages/form-advanced.init.js"></script>


<!-- Required datatable js -->
<script src="/assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<!-- Buttons examples -->
<script src="/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="/assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
<script src="/assets/libs/jszip/jszip.min.js"></script>
<script src="/assets/libs/pdfmake/build/pdfmake.min.js"></script>
<script src="/assets/libs/pdfmake/build/vfs_fonts.js"></script>
<script src="/assets/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="/assets/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="/assets/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>
<!-- Responsive examples -->
<script src="/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

<!-- Datatable init js -->
<script src="/assets/js/pages/datatables.init.js"></script>



<!--Form start-->
<script src="{{asset('/assets/js/pages/app.js')}}"></script>









