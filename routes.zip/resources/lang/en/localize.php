<?php

return [
    'welcome' => 'Welcome to our application',
    'home' => 'Home',
    'whole_sale' => 'Whole Sale',
    'offer' => 'Offer',
    'contact'=>'Contact',
    'category'=>'Category',
    'free_shipping'=>'Free Shipping on Orders upto 1500BDT',
    'sell_with_us'=>'Sell With Us',
    'sign_in'=>'Sign In',
    'sign_up'=>'Sign Up',
    'call_us'=>'Call Us',
    'search'=>'Search',
    'wellcome_to_mart_venue'=>'Welcome you to Mart Venue!',
    'all_categories'=>'All Categories',
    'search_products'=>'Search Products',
    'sports$more'=>'SPORTS & MORE',
    'appliances'=>'APPLIANCES',
    'home$kitchen'=>'HOME & KITCHEN',
    'women'=>'WOMEN',
    'men'=>'MEN',
    'mobiles$more'=>'MOBILES & MORE',
    'bdt'=>'BDT',
    'add_to_cart'=>'Add To Cart',
    'you_may_also_like'=>'Related Products',
    'details'=>'বিস্তারিত',
    'product_rating'=>'Product Rating',
    'filter_by'=>'Filter By',




];


?>
